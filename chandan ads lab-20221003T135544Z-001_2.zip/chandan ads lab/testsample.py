import sample
 
assert(sample.isnegative(-3)=='yes')
assert(sample.)
