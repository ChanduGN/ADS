def 1(list1):
    return max(list1)

def 2(list1):
    max_num1=max(list1)
    list1.remove(max_num1)
    max_num2=max(list1)
    return max_num2

def 3(list1):
	even_list=[]
	odd_list=[]
	for i in list1:
		if(i%2==0):
			even_list.append(i)
		else:
			odd_list.append(i)
	return even_list,odd_list

def 4(list1,list2):
	list1.sort()
	list2.sort()
	if(list1==list2):
		return True
	return False

def 5(list1, list2):
	list3=[]
	list3.extend(list1)
	for i in list2:
		if i not in list3:
			list3.append(i)
	return list3

def 6(list1,list2):
	list3=[]
	list1.sort()
	list2.sort()
	for i in list1:
		if i in list2:
			list3.append(i)
	return list3

def 7(list1,list2):
    list3=[]
    list4=[]
    list1.sort()
    list2.sort()
    list3.extend(list1)
    for i in list2:
        if i not in list3:
            list3.append(i)
    for i in list1:
        if i in list2:
            list4.append(i)
    return list3,list4

def 8(num):
	list1=[]
	list2=[]
	for i in range(0,num):
        squareNum=i*i
        list1.append(i)
        list1.append(squareNum)
        list2.append(tuple(list1[-2:]))
    return list2

def  9(list1):
    return list(set(list1))

def  10(list1):
    initial_one=len(list1[0])
    for i in list1:
        loop_one=len(i)
        if(initial_one<=loop_one):
            initial_one=loop_one
    return initial_one

def  11(dict1):
    dict1["abc"]=3
    return dict1

def  12(dict1,dict2):
    dict2.update(dict1)
    return dict2

def 13(dict1,key1):
    if key1 in dict1.keys():
        return True
    return False


def 14(num):
    dict1=dict()
    for i in range(0,num):
        dict1[i]=i*i
    return dict1

def 15(dict1):
    list1=[]
    for i in dict1:
        list1.append(dict1[i])
    return sum(list1)

def 16(dict1):
    list1=[]
    mul=1
    for i in dict1:
        list1.append(dict1[i])
    for j in list1:
    	mul=mul*j
    return mul

def 17(dict1):
    del dict1['a']
    return dict1

def 18(my_dict):
    if(len(my_dict)==0):
        return True
    return False


