#from ast import Num
#from unittest import result


def q1(n1,n2):
    n1,n2=n2,n1
    return n1,n2

def q2(n):
    if(n>0):
        return 1
    else:
        return 0

def q3(n):
        start=1
        end=100
        num=10
        res=[]
        for idx in range(start, end+1):
            if(idx%num==0):
              res.append(idx)
        return res

def q4(n1,n2):
    return n1%n2,n1/n2

def q5(n):
     res=[]
     for i in range(1, n+1):
        if (i%2!=0):
            res.append(i)
     return res

def q6(n):
    sum=0
    while(n != 0):
        reminder = n % 10
        sum = sum + reminder
        n = n // 10
    return sum

def q7(n):
    a=[]
    for i in range(2,n+1):
        if(n%i==0):
            a.append(i)
    a.sort()
    return a[0]

def q8(n):
    temp=str(n)
    t1=temp+temp
    t2=temp+temp+temp
    comp=n+int(t1)+int(t2)
    return comp

def q9(n):
    reversed_num = 0
    while n != 0:
        digit = n % 10
        reversed_num = reversed_num * 10 + digit
        n //= 10
    return reversed_num

def q10(n):
    sum=0
    for i in range(0,5):
        sum += n[i]
    avrg=sum/len(n)
    return avrg

def q11(n):
    o=0
    while (n):
        o=o + 1
        n = n // 10
    return o

def q12(n):
    rev=q9(n)
    if (rev == n):
        return 1
    else: 
        return 0

def q13(n,ss):
    return n.count(ss)

def q14(n,ss):
    return n.find(ss)

def q15(n):
    return n.isalpha()

def q16(n1,n2,n3):
    return n1.replace(n2,n3)

def q17(n):
    vowels = 0  
    for i in n:
        if(i == 'a' or i == 'e' or i == 'i' or i == 'o' or i == 'u' or i == 'A' or i == 'E' or i == 'I' or i == 'O' or i == 'U'):
            vowels = vowels + 1
    return vowels

def q18(n):
    return n.replace(' ','-')

def q19(n):
    count=0
    for i in n:
        count+=1
    return count

def q20(n1,n2):
    c1=0;c2=0
    for i in n1:
        c1+=1

    for i in n2:
        c2+=1
    if(c2>c1):
        return n2
    else:
        return n1

def q21(n):
    c1=0
    c2=0
    for i in n:
      if(i.islower()):
            c1=c1+1
      elif(i.isupper()):
            c2=c2+1
    return c1,c2

def q22(n):
    c1=0
    c2=0
    for i in n:
      if(i.isnumeric()):
            c1=c1+1
      elif(i.isalpha()):
            c2=c2+1
    return c1,c2

#23 pending
def q24(n):
    countsum = 0
    cumulativelist = []
    length = len(n)
    for i in range(length):
        countsum = countsum+n[i]
        cumulativelist.append(countsum)
    return cumulativelist 

import random
def q25(n):
    r_lst=[]
    for i in range(0,10):
        r_lst.append(random.randint(0, n))
    return r_lst

def q26():
    r_lst=[]
    for i in range(0,10):
        r_lst.append(random.randint(0, 20))
    return r_lst

def q27():
    #r_lst=[]
    r_lst=random.sample(range(1, 20), 5)
    return r_lst

def q28():
    num1 = random.randint(1, 10)
    num2 = random.randint(11, 20)
    num3 = random.randint(21, 30)
    num4 = random.randint(31, 40)
    num5 = random.randint(41, 50)
    num6 = random.randint(51, 60)
    num7 = random.randint(61, 70)
    num8 = random.randint(71, 80)
    num9 = random.randint(81, 90)
    num10 = random.randint(91, 100)
    lst=[num1,num2,num3,num4,num5,num6,num7,num8,num9,num10]
    return lst

    
        